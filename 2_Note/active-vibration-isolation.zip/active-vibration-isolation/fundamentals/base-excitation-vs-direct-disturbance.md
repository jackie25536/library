---
title: "Base Excitation vs Direct Disturbance"
type: topic
status: working
created: 2026-06-08
updated: 2026-06-08
tags:
  - active-vibration-isolation
  - fundamentals
  - base-excitation
  - direct-disturbance
  - 1-DOF
---

# Base Excitation vs Direct Disturbance

## 目的

本頁區分主動式隔震平台常見的兩類擾動：

- `base excitation`：地面、機台底座或外部環境造成的 base / floor motion。
- `direct disturbance`：直接作用在 payload / table 上的力，例如線纜拉力、平台上設備運動、負載變化、製程力或內部擾動。

兩者可能出現在同一台隔震平台，但 transfer function、性能指標與設計取捨不同。若混在一起，後續很容易把「隔震」與「擾動抑制」誤認為同一件事。

## 目前結論

- Base excitation 看的是 floor motion 多少傳到 payload，常用 `X/Y` 或 `xddot/yddot` transmissibility。
- Direct disturbance 看的是平台受到外力後位移多少，常用 compliance `X/F_d` 或 dynamic stiffness `F_d/X`。
- 被動隔震若把 spring 做軟、降低 `fn`，通常有利於高於 `sqrt(2)*fn` 的 floor isolation，但會讓 direct force 下的 static displacement `F_d/k` 變大。
- Damping 對兩類問題都會影響 resonance，但在高頻 base excitation 下，damper 會把 base velocity 傳上來；direct force path 則主要受 payload inertia 限制。
- 主動隔震的工程價值之一，是嘗試同時兼顧 floor isolation 與 direct disturbance rejection，而不是只優化其中一個 Bode plot。

## 同一個 plant，兩種輸入

從 1-DOF 模型開始：

```text
m*x_ddot + c*(x_dot - y_dot) + k*(x - y) = f_d
```

其中：

- `x`：payload absolute displacement。
- `y`：base / floor displacement。
- `f_d`：直接作用在 payload 上的 disturbance force。
- `z = x - y`：relative displacement / isolator stroke。

Laplace domain：

```text
(m*s^2 + c*s + k) X(s) = (c*s + k) Y(s) + F_d(s)
```

定義共同分母：

```text
D(s) = m*s^2 + c*s + k
```

則：

```text
X(s) = ((c*s + k) / D(s)) Y(s) + (1 / D(s)) F_d(s)
```

這表示同一個 payload motion `X` 來自兩條路徑：

```text
base path:   Y   -> X
force path:  F_d -> X
```

## Base excitation path：`Y -> X`

Transfer function：

```text
H_xy(s) = X(s) / Y(s)
        = (c*s + k) / (m*s^2 + c*s + k)
```

這是 dimensionless transmissibility。

物理問題：

> floor / base 動了多少，最後 payload 跟著動多少？

常見指標：

- displacement transmissibility `X/Y`。
- acceleration transmissibility `xddot/yddot`。
- relative stroke transmissibility `(X-Y)/Y`。

頻帶讀法：

- 低頻：`X/Y ~= 1`，payload 跟著 floor 動。
- 共振附近：`X/Y` 可能大於 `1`，base motion 被放大。
- 高頻：`X/Y` 可小於 `1`，進入 isolation region。

工程目標：

- 降低 floor-to-payload transmissibility。
- 控制 resonance peak。
- 避免 relative stroke 超限。

## Direct disturbance path：`F_d -> X`

當 base 固定或先只看 direct force effect，令 `Y = 0`：

```text
H_xf(s) = X(s) / F_d(s)
        = 1 / (m*s^2 + c*s + k)
```

這不是 transmissibility，而是 compliance，單位是 `m/N`。

也可以看 dynamic stiffness：

```text
K_dyn(s) = F_d(s) / X(s)
         = m*s^2 + c*s + k
```

物理問題：

> payload / table 上被直接施加一個力，平台位移多少？

常見指標：

- compliance `X/F_d`。
- dynamic stiffness `F_d/X`。
- direct disturbance response。
- settling time。
- static displacement under load change。

頻帶讀法：

- 低頻：`X/F_d ~= 1/k`，static compliance 由 spring stiffness 決定。
- 共振附近：compliance 變大，direct force 也容易激發 resonance。
- 高頻：`X/F_d ~= 1/(m*s^2)`，payload inertia 使高頻力較難造成大位移。

工程目標：

- 降低 direct disturbance 造成的 payload motion。
- 提高 apparent stiffness 或 active disturbance rejection。
- 避免 load change、線纜力或平台上設備運動造成 long settling。

## 關鍵取捨：低 stiffness 有利隔震，但不利 direct force

若只考慮 base excitation：

- 降低 `k` 會降低 `fn = sqrt(k/m)`。
- `fn` 越低，較低頻率就能進入 `f > sqrt(2)*fn` 的 isolation region。
- 因此軟隔震通常有利於 floor vibration isolation。

但若考慮 direct disturbance：

```text
static displacement = F_d / k
```

- `k` 越小，同樣 direct force 造成的 displacement 越大。
- 平台可能更容易被線纜力、負載變化或設備內部運動推動。

因此：

> 被動隔震中的「軟」通常有利於 floor isolation，但不利於 direct disturbance stiffness。

這是 active isolation 需要介入的重要原因之一。

## Damping 對兩條路徑的不同意義

### 對 base excitation

如 [Damping Tradeoff](damping-tradeoff.md) 所述：

- damping 增加可壓低 resonance peak。
- damping 增加會讓高頻 base velocity 更容易透過 damper 傳到 payload。

因此對 floor isolation 而言，damping 不是越大越好。

### 對 direct disturbance

對 direct force path：

- damping 同樣可壓低 resonance 附近的 response。
- static displacement 仍由 `1/k` 決定。
- 高頻下 response 主要由 inertia `m` 限制。

因此 direct disturbance rejection 常會想要：

- 提高 effective stiffness。
- 增加 resonance damping。
- 縮短 settling time。

但這些目標若只用被動元件實現，可能會犧牲 floor isolation。

## 和商用 IDE / Bode Plot 的關係

看到 Bode plot 時，第一件事是確認輸入與輸出：

| 類型 | 可能的 Bode | 物理意義 |
|---|---|---|
| Base excitation | payload acceleration / floor acceleration | floor vibration 傳到 payload 的比例 |
| Base excitation | payload displacement / floor displacement | displacement transmissibility |
| Stroke demand | relative displacement / floor displacement | isolator / actuator stroke 需求 |
| Direct disturbance | payload displacement / disturbance force | compliance |
| Direct disturbance | disturbance force / payload displacement | dynamic stiffness |

若沒有確認 Bode 的 input / output，調機結論可能會相反。例如：

- `X/Y` 越小通常代表 floor isolation 越好。
- `X/F_d` 越小代表 direct force compliance 越低。
- `(X-Y)/Y` 越大可能代表 isolation 有效，但 stroke demand 變大。

## 對 VCM 主動隔震的意義

VCM 可以作為 force actuator 介入兩類問題：

### 對 base excitation

可能目標：

- 透過 feedback / feedforward 降低 floor-to-payload transmissibility。
- 在 resonance 附近提供 active damping。
- 避免高頻 sensor noise 被控制力放大。

### 對 direct disturbance

可能目標：

- 偵測 payload motion 後產生反向 force。
- 提高 apparent stiffness。
- 縮短 direct disturbance 後的 settling time。

但 VCM force 會受限於：

- current limit。
- voltage limit。
- stroke limit。
- thermal limit。
- current loop bandwidth。
- sensor noise / delay。

## 對 C2000 實作的意義

未來 prototype 至少要分清楚兩種測試：

### Floor-to-payload transmissibility test

測試問題：

> base 被激振時，payload motion 有多少？

資料需求：

- floor / base sensor。
- payload sensor。
- frequency response estimation。

### Direct disturbance / compliance test

測試問題：

> payload 被直接施力時，payload motion 有多少？

資料需求：

- force injection 或已知 actuator force。
- payload sensor。
- settling / compliance measurement。

C2000 可能需要支援：

- force injection。
- base excitation logging。
- payload motion logging。
- mode 切換與 safety limit。

## 和馬達控制的共同語言

可粗略對應：

- Base excitation：像是機台或負載端外部基座振動傳入系統。
- Direct disturbance：像是 load torque / external force 直接作用在控制對象上。
- Compliance：類似受外力時的位置偏移量，和 stiffness / disturbance rejection 有關。

但隔震平台的困難在於：

- 想隔離 base motion，常希望 passive stiffness 低。
- 想抑制 direct force，常希望 apparent stiffness 高。
- 這兩件事在被動設計中互相衝突。

## 設計判斷

對主動式隔震平台，不能只問：

> transmissibility 好不好？

還要問：

- direct disturbance response 好不好？
- relative stroke 會不會超限？
- active force / current 是否足夠？
- control bandwidth 是否覆蓋目標頻帶？
- sensor 是否能分辨 floor motion 與 payload motion？

## Gate 檢查

目前通過：

- 能寫出同時包含 `Y` 與 `F_d` 的 1-DOF equation。
- 能區分 `X/Y` 是 transmissibility，`X/F_d` 是 compliance。
- 能說明低 stiffness 對 floor isolation 與 direct disturbance response 的相反影響。
- 能說明未來測試與 Bode plot 必須先確認 input / output。

後續仍需補：

- `m / k / c / fn / zeta` 對被動設計參數的系統性影響。
- 用模擬對比 base path 與 force path 的 Bode，可作為後續補充。

