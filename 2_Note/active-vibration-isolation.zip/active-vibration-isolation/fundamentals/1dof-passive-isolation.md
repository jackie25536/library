---
title: "1-DOF 被動隔震模型"
type: topic
status: working
created: 2026-06-07
updated: 2026-06-07
tags:
  - active-vibration-isolation
  - fundamentals
  - 1-DOF
  - transmissibility
  - simulation
---

# 1-DOF 被動隔震模型

## 目的

本頁建立主動式隔震研究的第一個基礎模型：1-DOF mass-spring-damper 在 base excitation 下的被動隔震特性。

這個模型不代表最終 6-DoF VCM 平台，但它是理解 transmissibility、resonance、damping tradeoff 與後續主動控制的最小入口。

## 目前結論

- 被動隔震不是「全頻都變好」：低頻時 payload 會跟著地面動，幾乎沒有隔震。
- 在 natural frequency 附近會有 resonance peak，阻尼太小會造成明顯放大。
- 增加 damping 可以壓低 resonance peak，但會讓高頻隔震變差。
- 對 absolute displacement transmissibility `X/Y` 而言，理想線性模型中約在 `f > sqrt(2) * fn` 後才進入 `|X/Y| < 1` 的隔震區。
- 這個 tradeoff 是後續 active damping、skyhook、filter 與 sensor noise 討論的基礎。

## 模型與假設

模型：

```text
base/floor y(t) -> spring + damper -> payload mass x(t)
```

變數：

- `x`：payload absolute displacement。
- `y`：base / floor displacement。
- `z = x - y`：payload 相對 base displacement。
- `m`：payload mass。
- `k`：spring stiffness。
- `c`：damping coefficient。

假設：

- 單自由度線性模型。
- spring / damper 只接在 payload 與 base 之間。
- base displacement 是外部輸入。
- 尚未納入 actuator、sensor noise、stroke limit、friction、結構彈性模態與 6-DOF coupling。

## 數學推導

運動方程式：

```text
m*x_ddot + c*(x_dot - y_dot) + k*(x - y) = 0
```

移到 Laplace domain：

```text
(m*s^2 + c*s + k) X(s) = (c*s + k) Y(s)
```

因此 absolute displacement transmissibility 為：

```text
H_xy(s) = X(s) / Y(s) = (c*s + k) / (m*s^2 + c*s + k)
```

定義：

```text
omega_n = sqrt(k / m)
zeta = c / (2*m*omega_n)
r = omega / omega_n
```

在 `s = j*omega` 時：

```text
H_xy(j*omega) = (1 + j*2*zeta*r) / (1 - r^2 + j*2*zeta*r)
```

其 magnitude：

```text
|X/Y| = sqrt((1 + (2*zeta*r)^2) / ((1 - r^2)^2 + (2*zeta*r)^2))
```

工程讀法：

- `r << 1`：`|X/Y| ~= 1`，payload 幾乎跟著 base 動。
- `r ~= 1`：接近 natural frequency，可能出現 resonance amplification。
- `r > sqrt(2)`：開始進入 `|X/Y| < 1` 的隔震區。
- `r >> 1`：`|X/Y| ~= 2*zeta/r`，因此 damping 越大，高頻傳遞反而越高。

## Python 模擬

可重跑腳本：

- [01_1dof_passive_isolation.py](../../../../../simulations/active-vibration-isolation/01_1dof_passive_isolation.py)

輸出資料：

- [01_summary.csv](../../../../../simulations/active-vibration-isolation/data/01_summary.csv)
- [01_transmissibility_damping_sweep.csv](../../../../../simulations/active-vibration-isolation/data/01_transmissibility_damping_sweep.csv)

模擬參數：

| 參數 | 數值 | 備註 |
|---|---:|---|
| `m` | `20 kg` | 範例 payload mass，不是實機規格 |
| `fn` | `5 Hz` | 範例 natural frequency |
| base amplitude | `10 um` | time response 範例輸入 |
| damping ratio | `0.02, 0.05, 0.10, 0.20, 0.50, 1.00` | 用於觀察 damping tradeoff |

## 模擬結果

### Transmissibility damping sweep

![1-DOF transmissibility damping sweep](../../../../../simulations/active-vibration-isolation/figures/01_transmissibility_damping_sweep.svg)

觀察：

- `zeta = 0.02` 時 resonance peak 很高，約 `27.87 dB`。
- `zeta = 0.20` 時 resonance peak 降到約 `8.73 dB`。
- `zeta = 1.00` 時 peak 只剩約 `1.25 dB`，但高頻隔震明顯變差。
- 所有阻尼比約在 `sqrt(2) * fn` 之後才進入 `0 dB` 以下，這是 base-excited passive isolation 的基本限制。

### Time response at natural frequency

![1-DOF time response at resonance](../../../../../simulations/active-vibration-isolation/figures/01_time_response_at_resonance.svg)

觀察：

- 圖中 base input 為 `10 um` sine，頻率等於 `fn = 5 Hz`。
- 低阻尼時 payload response 會被 resonance 放大。
- 較高阻尼可以降低 resonance amplification，但這不代表高頻隔震也更好。

### 數值摘要

| Damping ratio `zeta` | Peak | Peak freq | `|X/Y|` at `10 fn` |
|---:|---:|---:|---:|
| `0.02` | `27.87 dB` | `5.01 Hz` | `-39.27 dB` |
| `0.05` | `20.03 dB` | `4.97 Hz` | `-36.90 dB` |
| `0.10` | `14.18 dB` | `4.97 Hz` | `-32.92 dB` |
| `0.20` | `8.73 dB` | `4.81 Hz` | `-27.62 dB` |
| `0.50` | `3.33 dB` | `4.27 Hz` | `-19.91 dB` |
| `1.00` | `1.25 dB` | `3.54 Hz` | `-14.05 dB` |

關鍵 tradeoff：

- damping 增加：resonance peak 下降。
- damping 增加：`10 fn` 的高頻 transmissibility 變大，隔震變差。

延伸說明：

- [Damping Tradeoff：阻尼壓共振但犧牲高頻隔震](damping-tradeoff.md)

## 工程映射

### 和馬達控制的共同語言

這個模型可對應到馬達控制裡常見的機械共振與負載柔性：

- `fn` 類似機械共振頻率。
- `zeta` 類似機械阻尼或控制器加入的 damping 效果。
- Bode peak 類似速度/位置迴路中會限制 bandwidth 的機械共振。

但主動隔震的主要目標不是 tracking command，而是降低 base / floor vibration 傳到 payload 的程度。

### 對 VCM 主動隔震的意義

被動隔震的 damping tradeoff 說明：

- 只靠機械 damping 很難同時壓 resonance 又保持高頻隔震。
- 主動控制的價值之一，是嘗試在需要的頻帶提供等效 damping 或 disturbance rejection。
- 但主動控制會引入 sensor noise、phase delay、actuator force limit 與 stability margin 問題。

### 對 C2000 實作的意義

此階段尚未進入 C2000 實作，但已暗示後續韌體必須面對：

- 目標頻帶相對 `fn` 的位置。
- outer vibration loop 的 bandwidth 不可任意提高。
- 若使用 VCM，force command 最後會受到 current loop bandwidth 與 force/current limit 限制。

## Gate 檢查

目前通過：

- 能說明低頻時 `|X/Y| ~= 1`，所以被動隔震在低頻很難有效。
- 能說明 resonance 附近可能放大 base vibration。
- 能說明 damping 增加會壓 resonance peak，但會犧牲高頻隔震。

尚未處理：

- 主動控制如何改善這個 tradeoff。
- sensor noise / delay 如何限制 active damping。
- VCM current loop 如何限制 force command。
- 3-DOF / 6-DOF 時，transmissibility 如何擴展成 MIMO frequency response。
- base excitation 與 direct disturbance 的完整比較見 [Base Excitation vs Direct Disturbance](base-excitation-vs-direct-disturbance.md)。

## 下一步

Milestone 1 的下一個技術模組：

- `passive-isolation-design-parameters.md`：整理 `m / k / c / fn / zeta` 對被動隔震設計的影響。
