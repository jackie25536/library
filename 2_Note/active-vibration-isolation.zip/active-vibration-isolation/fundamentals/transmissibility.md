---
title: "Transmissibility 定義與物理意義"
type: topic
status: working
created: 2026-06-08
updated: 2026-06-08
tags:
  - active-vibration-isolation
  - fundamentals
  - transmissibility
  - Bode
  - 1-DOF
---

# Transmissibility 定義與物理意義

## 目的

本頁整理 1-DOF base-excited passive isolation 中常見的 transmissibility 定義，避免後續閱讀 paper、Bode plot 或商用 IDE 時，把不同物理量混成同一個結論。

核心提醒：

- `X/Y` 看的是 payload absolute motion 相對 floor/base motion 的傳遞。
- `(X-Y)/Y` 看的是 isolator stroke / relative motion demand。
- `xddot/yddot` 若兩者都是 absolute acceleration ratio，在 harmonic transfer function 中與 `X/Y` 相同，但實務上常由 accelerometer 量測取得。

## 模型

沿用 [1-DOF 被動隔震模型](1dof-passive-isolation.md)：

```text
m*x_ddot + c*(x_dot - y_dot) + k*(x - y) = 0
```

其中：

- `x`：payload absolute displacement。
- `y`：base / floor displacement。
- `z = x - y`：payload 相對 base displacement，也可視為 isolator stroke。

## 定義 1：Absolute displacement transmissibility `X/Y`

定義：

```text
H_xy(s) = X(s) / Y(s)
        = (c*s + k) / (m*s^2 + c*s + k)
```

標準化形式：

```text
omega_n = sqrt(k / m)
zeta = c / (2*m*omega_n)
r = omega / omega_n

H_xy(j*omega) = (1 + j*2*zeta*r) / (1 - r^2 + j*2*zeta*r)
```

物理意義：

- `|X/Y| = 1`：payload absolute motion 和 base motion 一樣大，沒有隔震。
- `|X/Y| > 1`：payload motion 被放大，通常發生在 resonance 附近。
- `|X/Y| < 1`：payload motion 小於 base motion，進入隔震區。

工程讀法：

- 這是最直接的「地面振動有多少傳到 payload」指標。
- 若目標是保護平台上的設備不受 floor vibration 影響，通常會很關心此 ratio。
- 對理想線性 1-DOF 模型，`r = sqrt(2)` 時 `|X/Y| = 1`，超過後才進入 `0 dB` 以下。

## 定義 2：Relative displacement transmissibility `(X-Y)/Y`

定義：

```text
H_zy(s) = Z(s) / Y(s)
        = (X(s) - Y(s)) / Y(s)
        = H_xy(s) - 1
        = -m*s^2 / (m*s^2 + c*s + k)
```

物理意義：

- 這不是 payload isolation performance 的直接指標。
- 它看的是 isolator 需要吸收多少相對位移，也就是 stroke demand。
- 低頻時 payload 跟著 base 動，所以 `x ~= y`，`z = x-y` 很小。
- 高頻時 payload 趨近不動、base 在動，所以 `z ~= -y`，`|Z/Y|` 趨近 `1`。

工程讀法：

- `X/Y` 變小通常表示 payload 隔震變好。
- `(X-Y)/Y` 變大則表示機構 stroke 或 actuator stroke 需求變大。
- 因此「隔震變好」可能同時代表「相對行程需求變大」，這會連到 stroke limit 與 VCM 行程設計。

## 定義 3：Acceleration transmissibility `xddot/yddot`

若定義為 absolute payload acceleration over absolute base acceleration：

```text
H_aa(s) = X_ddot(s) / Y_ddot(s)
        = s^2 X(s) / (s^2 Y(s))
        = X(s) / Y(s)
```

因此在 harmonic transfer function 中：

```text
H_aa = H_xy
```

物理意義：

- 數學上，它和 `X/Y` 是同一個 ratio。
- 實務上，常用 accelerometer 量測 floor acceleration 與 payload acceleration，因此 Bode plot 可能標成 acceleration transmissibility。
- 若輸入與輸出不是同一階導數，例如 payload acceleration over base displacement，則不是這裡的 dimensionless transmissibility。

工程讀法：

- 看到 paper 或 IDE 的 acceleration transmissibility 時，要先確認定義是否為 `payload acceleration / floor acceleration`。
- 若是，對線性 harmonic 分析而言可和 `X/Y` 用同一條 transmissibility 曲線理解。
- 但實際量測會受 accelerometer noise、低頻 drift、integration / filtering 與 phase delay 影響。

## Python 模擬

可重跑腳本：

- [01b_1dof_transmissibility_variants.py](../../../../../simulations/active-vibration-isolation/01b_1dof_transmissibility_variants.py)

輸出資料：

- [01b_summary.csv](../../../../../simulations/active-vibration-isolation/data/01b_summary.csv)
- [01b_transmissibility_variants.csv](../../../../../simulations/active-vibration-isolation/data/01b_transmissibility_variants.csv)

模擬參數：

| 參數 | 數值 | 備註 |
|---|---:|---|
| `m` | `20 kg` | 範例 payload mass，不是實機規格 |
| `fn` | `5 Hz` | 範例 natural frequency |
| `zeta` | `0.10` | 用於比較不同 transmissibility 定義 |

## 模擬結果

![1-DOF transmissibility variants](../../../../../simulations/active-vibration-isolation/figures/01b_transmissibility_variants.svg)

數值摘要：

| Probe | `X/Y` | `(X-Y)/Y` | `xddot/yddot` |
|---:|---:|---:|---:|
| `0.1 fn` | `0.09 dB` | `-39.91 dB` | `0.09 dB` |
| `1 fn` | `14.15 dB` | `13.98 dB` | `14.15 dB` |
| `sqrt(2) fn` | `0.00 dB` | `5.69 dB` | `0.00 dB` |
| `10 fn` | `-32.92 dB` | `0.09 dB` | `-32.92 dB` |

觀察：

- `X/Y` 與 `xddot/yddot` 重合，因為兩者都是 absolute motion ratio。
- 低頻 `0.1 fn` 時，`X/Y ~= 0 dB`，payload 幾乎跟著 base 動；但 `(X-Y)/Y` 很小，表示相對行程很小。
- `fn` 附近三者中 `X/Y` 與 `(X-Y)/Y` 都很大，表示 payload motion 與 relative stroke 都被 resonance 放大。
- `10 fn` 時，`X/Y` 已經很小，表示 payload absolute motion 被隔離；但 `(X-Y)/Y ~= 0 dB`，表示相對行程幾乎等於 base motion。

## 常見混淆

### 混淆 1：看到 transmissibility 就以為都是 `X/Y`

不一定。Paper 或儀器可能看的是：

- payload displacement / floor displacement。
- payload acceleration / floor acceleration。
- relative displacement / floor displacement。
- payload force response / floor excitation。

如果沒有先確認輸入與輸出，Bode plot 的結論可能會讀錯。

### 混淆 2：把 relative stroke 下降當成隔震變好

Relative stroke 小不一定代表 payload vibration 小。低頻時 payload 跟 base 一起動，relative stroke 也很小，但沒有隔震效果。

### 混淆 3：把 acceleration transmissibility 當成和 displacement transmissibility 完全不同的動態

若兩者都是 absolute output / absolute input 的同階 ratio，`xddot/yddot = X/Y`。差異主要在量測方法與 sensor limitation，而不是線性 transfer function 本身。

## 工程映射

### 對隔震平台調機

調機時至少要分清楚兩個問題：

- payload 是否真的被隔離：看 `X/Y` 或 `xddot/yddot`。
- 機構或 actuator 是否快撞行程：看 `(X-Y)/Y` 或實際 stroke。

這兩個目標可能衝突。高頻隔震好時，payload absolute motion 小，但 base 與 payload 的相對位移可能接近 base motion。

### 對 VCM 實作

VCM 主動隔震不只要降低 payload motion，也要避免：

- stroke 超限。
- force command 過大。
- current command 飽和。
- active control 在 resonance 附近放大相對位移。

因此後續 active control 的評估圖不應只看 payload transmissibility，也要看 relative stroke 與 control force。

### 對 C2000 實作

若未來用 accelerometer 做 Bode / FRF：

- `payload acceleration / floor acceleration` 可作為 transmissibility 指標。
- 低頻 accelerometer noise / drift 可能影響可用性。
- 若需要 stroke protection，仍要有 position / relative displacement 估測或額外 sensor。

## Gate 檢查

目前通過：

- 能區分 `X/Y`、`(X-Y)/Y`、`xddot/yddot`。
- 能說明 `xddot/yddot` 在 harmonic ratio 下與 `X/Y` 相同。
- 能說明 `(X-Y)/Y` 代表 stroke demand，不是直接的 isolation performance。

後續仍需補：

- damping tradeoff 對 `X/Y` 與 stroke 的不同影響。
- base excitation 與 direct disturbance 的 transfer function 差異。

