---
title: "Damping Tradeoff：阻尼壓共振但犧牲高頻隔震"
type: topic
status: working
created: 2026-06-08
updated: 2026-06-08
tags:
  - active-vibration-isolation
  - fundamentals
  - damping
  - transmissibility
  - 1-DOF
---

# Damping Tradeoff：阻尼壓共振但犧牲高頻隔震

## 目的

本頁整理 1-DOF 被動隔震中的核心 tradeoff：

> 增加 damping 可以壓低 resonance peak，但會讓高頻隔震變差。

這個現象是後續 active damping、skyhook damping、filter design 與 VCM force control 的基礎。若沒有先理解這個被動系統限制，很容易誤以為「阻尼越大越好」或「gain 越高越好」。

## 目前結論

- 對 base excitation 的 `X/Y` transmissibility，damping ratio `zeta` 增加會降低 natural frequency 附近的放大。
- 但在高頻區，viscous damper 會把 base velocity 造成的力傳到 payload，因此 damping 越大，高頻 transmissibility 越高。
- Passive isolation 的設計不是最大化 damping，而是在 resonance amplification、settling、stroke demand 與高頻 isolation 之間取捨。
- Active control 的價值之一，是嘗試做出「在需要的頻帶提供 damping，但不要把高頻 base vibration 透過 damper 硬傳上來」的效果。

## 前置定義

沿用 [1-DOF 被動隔震模型](1dof-passive-isolation.md) 與 [Transmissibility 定義與物理意義](transmissibility.md)：

```text
m*x_ddot + c*(x_dot - y_dot) + k*(x - y) = 0
```

absolute displacement transmissibility：

```text
H_xy(j*omega) = X/Y
              = (1 + j*2*zeta*r) / (1 - r^2 + j*2*zeta*r)
```

其中：

```text
r = omega / omega_n
zeta = c / (2*m*omega_n)
```

## 為什麼 damping 可以壓 resonance

在 `r ~= 1` 附近，系統接近 natural frequency。若 damping 很小，分母中的能量耗散很弱，payload response 會被放大。

在 `r = 1` 時：

```text
|X/Y| = sqrt(1 + (2*zeta)^2) / (2*zeta)
```

當 `zeta` 很小時，可近似為：

```text
|X/Y| ~= 1 / (2*zeta)
```

因此：

- `zeta` 越小，resonance peak 越高。
- `zeta` 增加，resonance peak 下降。

工程直覺：

- damping 在 resonance 附近提供能量耗散。
- 若沒有足夠 damping，base vibration 會在 spring-mass 系統中累積成大振幅。

## 為什麼 damping 會犧牲高頻隔震

高頻時，payload mass 因 inertia 較不容易跟著 base 動，這本來是隔震成立的原因。

但 damper 連在 payload 與 base 之間，其力為：

```text
F_d = c*(x_dot - y_dot)
```

高頻隔震區中，若 payload 幾乎不動，則：

```text
x_dot ~= 0
F_d ~= -c*y_dot
```

也就是 base velocity 會透過 damper 形成一個直接作用到 payload 的力。`c` 越大，這條速度傳遞路徑越強。

從 transmissibility 公式看，高頻時：

```text
|X/Y| ~= 2*zeta / r
```

因此在相同高頻 `r` 下：

- `zeta` 越大，`|X/Y|` 越大。
- 高頻隔震越差。

工程直覺：

- spring 在高頻下較不容易把 displacement 傳上來。
- damper 會把 base velocity 造成的力傳上來。
- 所以過大的 viscous damping 會短路掉高頻隔震效果。

## 模擬證據

使用現有模擬：

- [01_1dof_passive_isolation.py](../../../../../simulations/active-vibration-isolation/01_1dof_passive_isolation.py)
- [01_summary.csv](../../../../../simulations/active-vibration-isolation/data/01_summary.csv)

![1-DOF transmissibility damping sweep](../../../../../simulations/active-vibration-isolation/figures/01_transmissibility_damping_sweep.svg)

數值摘要：

| Damping ratio `zeta` | Resonance peak | Peak freq | `|X/Y|` at `10 fn` |
|---:|---:|---:|---:|
| `0.02` | `27.87 dB` | `5.01 Hz` | `-39.27 dB` |
| `0.05` | `20.03 dB` | `4.97 Hz` | `-36.90 dB` |
| `0.10` | `14.18 dB` | `4.97 Hz` | `-32.92 dB` |
| `0.20` | `8.73 dB` | `4.81 Hz` | `-27.62 dB` |
| `0.50` | `3.33 dB` | `4.27 Hz` | `-19.91 dB` |
| `1.00` | `1.25 dB` | `3.54 Hz` | `-14.05 dB` |

讀法：

- `zeta = 0.02`：resonance peak 很高，但 `10 fn` 隔震很好。
- `zeta = 1.00`：resonance peak 幾乎被壓住，但 `10 fn` 高頻隔震明顯變差。
- 這不是模擬參數偶然，而是被動 viscous damping 的結構性 tradeoff。

## 三個頻帶的工程讀法

### 低頻：`r << 1`

```text
|X/Y| ~= 1
```

payload 幾乎跟著 base 動。

工程含義：

- 被動隔震對低頻 floor motion 幫助有限。
- 要改善低頻，通常需要主動控制、feedforward、低剛性設計或其他架構手段。

### 共振附近：`r ~= 1`

```text
|X/Y| peak ~= 1 / (2*zeta)
```

damping 是壓低 resonance peak 的主要手段。

工程含義：

- damping 太小，平台在 `fn` 附近會被放大。
- 若客戶現場 floor vibration 接近 `fn`，低 damping 可能造成大振幅。

### 高頻：`r >> 1`

```text
|X/Y| ~= 2*zeta / r
```

damping 越大，高頻 transmissibility 越高。

工程含義：

- 要追求高頻隔震，不能只靠大 damping。
- damper 的速度傳力路徑會破壞高頻隔震。

## 設計判斷

### 被動系統

被動 damping 選擇要同時考慮：

- resonance peak 可接受程度。
- 高頻 isolation 需求。
- settling time。
- relative stroke demand。
- payload mass 與 natural frequency 變動。

因此被動 damping 不是越大越好。

### 主動系統

主動控制常見目標之一，是模仿「只在需要的頻帶增加 damping」：

- 在 resonance 附近提供 damping，降低 peak。
- 避免在高頻把 sensor noise 或 base velocity 硬傳到 payload。
- 透過 filter / loop shaping 限制控制作用頻帶。

這也是後續 skyhook damping 與 frequency-shaped control 的直覺入口。

### VCM force actuator

若使用 VCM 主動提供 damping-like force：

```text
F_cmd ~= -b_active * x_dot
```

或某種 velocity feedback，必須同步觀察：

- payload transmissibility。
- relative stroke。
- force command。
- current command。
- sensor noise 放大。
- phase margin。

否則可能壓低 resonance peak，但造成 actuator current 太大或高頻噪聲被放大。

## 和馬達控制的共同語言

可類比到 servo / motor control：

- mechanical resonance peak 限制 loop bandwidth。
- damping / notch / filter 可壓 peak，但會影響相位與高頻響應。
- gain 不能無限制提高，因為 noise、delay、saturation 與未建模模態會進來。

但隔震問題的目標不同：

- 馬達控制常看 tracking error、速度/位置命令響應。
- 隔震平台更常看 floor-to-payload transmissibility、direct disturbance response、relative stroke 與平台穩定度。

## 常見錯誤

### 錯誤 1：阻尼越大越好

錯。阻尼越大，共振越低，但高頻隔震越差。

### 錯誤 2：只看 resonance peak

不夠。只看 peak 可能會選到過大的 damping，讓高頻隔震性能下降。

### 錯誤 3：主動 damping 等於無副作用地增加 damping

不對。主動 damping 會受到 sensor noise、phase delay、actuator limit 與 controller stability 限制。

### 錯誤 4：高頻隔震好就代表整體設計好

不一定。若 damping 太小，resonance peak 可能非常高，實機可能在低頻或共振附近不可接受。

## 對後續 milestone 的意義

Milestone 2 的 active control 應從這個問題出發：

> 能不能用主動控制在 resonance 附近提供有效 damping，同時不要犧牲高頻隔震，也不要放大 sensor noise？

因此下一階段模擬不能只畫 `X/Y`，還要同步看：

- control force。
- relative stroke。
- sensor noise sensitivity。
- phase / delay effect。

## Gate 檢查

目前通過：

- 能說明 damping 為什麼壓低 resonance。
- 能說明 damping 為什麼犧牲高頻 isolation。
- 能用 simulation result 解讀 damping ratio sweep。
- 能說明 active damping 後續要解決的核心矛盾。

後續仍需補：

- base excitation 與 direct disturbance 的差異。
- passive design parameters 如何從 `m / k / c / fn / zeta` 轉成實際設計選擇。

