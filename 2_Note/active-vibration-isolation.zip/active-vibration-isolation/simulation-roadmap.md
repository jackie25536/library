---
title: "主動式隔震平台模擬路線"
type: topic
status: working
created: 2026-06-07
updated: 2026-06-07
tags:
  - active-vibration-isolation
  - simulation
  - Python
  - modeling
---

# 主動式隔震平台模擬路線

## 定位

本頁定義主動式隔震研究中的 Python 模擬路線。

模擬不是為了做漂亮圖，而是用來建立控制直覺、驗證推導、連結工程限制，並支撐後續 C2000 prototype 設計。

## 模擬原則

每個模擬都必須回答一個具體問題，例如：

- damping 增加為什麼會壓低 resonance peak，但可能讓高頻隔震變差？
- active feedback 為什麼會改善低頻/共振附近表現，但放大 sensor noise？
- VCM current loop bandwidth 會如何限制外層隔震控制？
- 6-DOF 中某一軸控制為什麼會激發另一軸？

每個模擬都要保留：

- 模型假設。
- 方程式。
- 參數表。
- Bode plot 或 frequency response。
- time response。
- 觀察結論。
- 工程映射。
- 待驗證問題。

## 檔案規劃

預計使用 Python 腳本作為可重跑模擬來源：

```text
simulations/active-vibration-isolation/
  01_1dof_passive_isolation.py
  02_1dof_active_skyhook.py
  03_sensor_noise_filter_tradeoff.py
  04_vcm_force_actuator_current_loop.py
  05_3dof_platform_transform.py
  06_6dof_mimo_bode_matrix.py
  07_discrete_time_c2000_effects.py
  figures/
  reports/
```

初期以 `.py` 為主，因為版本乾淨、容易重跑、容易被 wiki 引用。若後續需要互動參數，再補 HTML 或 notebook。

## 輸出分工

- Markdown：知識庫 source of truth，記錄 current-best 理解。
- Python：可重跑的模擬 source of truth。
- PNG / SVG：固定圖表。
- HTML：閱讀報告、互動圖或季度回顧，不作為唯一維護來源。

不建議手動維護 Markdown 與 HTML 兩份互相重複的內容。HTML 應由 Markdown、Python 結果與圖表自動或半自動產生。

## Simulation 1：1-DOF 被動隔震 transmissibility

狀態：第一版已建立。

可重跑腳本：

- [01_1dof_passive_isolation.py](../../../../simulations/active-vibration-isolation/01_1dof_passive_isolation.py)
- [01b_1dof_transmissibility_variants.py](../../../../simulations/active-vibration-isolation/01b_1dof_transmissibility_variants.py)

對應技術文件：

- [1-DOF 被動隔震模型](fundamentals/1dof-passive-isolation.md)
- [Transmissibility 定義與物理意義](fundamentals/transmissibility.md)

問題：

- mass-spring-damper 在 base excitation 下的 transmissibility 長什麼樣？
- damping ratio 增加時，resonance peak 與高頻隔震如何改變？

模型：

- 1-DOF mass-spring-damper。
- 輸入為 base displacement。
- 輸出為 payload displacement 或相對位移。

輸出：

- transmissibility Bode plot。
- damping ratio sweep。
- base sine input 的 time response。

Gate：

- 能說明為什麼低頻隔震困難。
- 能說明 resonance 與 damping tradeoff。

## Simulation 2：1-DOF 主動 damping / skyhook / PD

問題：

- active damping 如何壓低 resonance？
- skyhook damping 與一般 velocity feedback 在簡化模型下有什麼關係？
- PD gain 提高後的限制是什麼？

模型：

- 在 1-DOF plant 上加入控制力。
- 初期用理想 force actuator。
- 逐步加入 force limit。

輸出：

- passive vs active transmissibility。
- resonance peak comparison。
- control force time response。

Gate：

- 能說明 active control 不能只看平台響應，也要看控制力與穩定裕度。

## Simulation 3：sensor noise and filter tradeoff

問題：

- sensor noise 如何限制 active control？
- low-pass / high-pass / notch filter 對 Bode 與 noise 有什麼影響？
- filter phase delay 如何吃掉 phase margin？

模型：

- 在 velocity 或 acceleration feedback 路徑加入 noise。
- 在 feedback path 加入簡化 filter。
- 比較 noise-free 與 noisy case。

輸出：

- noise amplification comparison。
- filtered vs unfiltered response。
- controller output RMS。

Gate：

- 能說明 IDE 中 filter 調整不是裝飾，而是穩定性與噪聲的核心。

## Simulation 4：VCM force actuator + current loop

問題：

- force command 如何轉成 current command？
- current loop bandwidth 會如何限制外層隔震控制？
- current / voltage / force saturation 會造成什麼現象？

模型：

- VCM force constant。
- first-order current loop。
- current / force limit。
- optional back EMF effect。

輸出：

- ideal force actuator vs finite current loop bandwidth。
- force command tracking。
- saturation case。

Gate：

- 能把外層隔震控制輸出的 force command 對應到 C2000 current loop。

## Simulation 5：3-DOF z / roll / pitch platform transform

問題：

- 多個 actuator force 如何形成平台 z / roll / pitch motion？
- local control 與 mode control 差在哪裡？
- actuator placement 對 coupling 有什麼影響？

模型：

- 剛體平台的 z / roll / pitch。
- 3 個或 4 個垂直 VCM。
- actuator force 到 generalized force 的 transformation matrix。

輸出：

- actuator-to-mode matrix。
- mode command to actuator force allocation。
- local control vs mode control response。

Gate：

- 能說明多個 actuator 不等於多個獨立 SISO axis。

## Simulation 6：6-DOF MIMO Bode matrix

問題：

- 6-DOF plant 的 diagonal / off-diagonal response 如何觀察？
- 為什麼某軸控制會激發另一軸？
- decoupling matrix 是在改善什麼？

模型：

- 簡化 6-DOF rigid body plant。
- actuator / sensor matrix。
- 初步 MIMO frequency response。

輸出：

- MIMO Bode matrix。
- diagonal vs off-diagonal comparison。
- before / after simple decoupling。

Gate：

- 能看懂單軸 Bode 與 MIMO Bode matrix 的差異。

## Simulation 7：discrete-time / C2000-oriented effects

問題：

- sampling、delay、saturation、anti-windup 對隔震控制有什麼影響？
- 連續時間看起來穩定的控制器，離散化後是否仍可用？
- 6-DOF matrix computation 是否可能放在即時迴路？

模型：

- 離散時間 controller。
- sample-and-hold。
- computational delay。
- saturation / anti-windup。

輸出：

- continuous vs discrete response。
- delay sensitivity。
- CPU / CLA computation estimate placeholder。

Gate：

- 能定義最小可跑 prototype 的即時控制條件。

## HTML 閱讀層

HTML 適合用在：

- 一個 milestone 的總結報告。
- 有很多圖，需要比 Markdown 更好閱讀。
- 互動 Bode plot、hover data、參數切換。
- 把模型、方程式、圖、解讀放成連續閱讀的 study report。

初期策略：

- Markdown 記核心概念與結論。
- Python 產生圖。
- Markdown 嵌圖。
- 每季再產生一份 HTML review report。

## 待補

- 建立下一個 `fundamentals/passive-isolation-design-parameters.md`。
- Milestone 1 完成後再建立 `02_1dof_active_skyhook.py`。
- 依第一個模擬的 SVG / CSV 輸出方式，整理共用繪圖或資料輸出 helper 的必要性。
- 決定是否維持零 `scipy` / `matplotlib` 依賴，或在有明確需求時再引入額外工具。
- 建立模擬結果回寫 wiki 的固定格式。
