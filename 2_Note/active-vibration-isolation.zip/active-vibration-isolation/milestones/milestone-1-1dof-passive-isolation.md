---
title: "Milestone 1：1-DOF 被動隔震模型"
type: milestone
status: active
created: 2026-06-08
updated: 2026-06-08
tags:
  - active-vibration-isolation
  - milestone
  - 1-DOF
  - passive-isolation
---

# Milestone 1：1-DOF 被動隔震模型

## 目標

建立 1-DOF passive isolation 的物理直覺、數學模型、Bode / transmissibility 觀察能力，作為後續 active control、VCM force actuator 與多自由度隔震模型的基礎。

本 milestone 不追求完整產品模型，也不處理 6-DOF、H-infinity、LMI 或進階 paper 方法。

## 完成標準

完成本 milestone 時，應能做到：

- 推導 base excitation 下的 1-DOF equation of motion。
- 說明 absolute displacement transmissibility `X/Y` 的物理意義。
- 解釋 resonance peak 與 damping ratio 的關係。
- 解釋 damping 增加後，高頻隔震為什麼可能變差。
- 區分 base excitation 與 payload direct disturbance。
- 看懂第一版 Python 模擬圖與數值結果。
- 知道 Milestone 2 為什麼要進入 active damping / skyhook / PD control。

## 子項目

| 狀態 | 項目 | 目的 |
|---|---|---|
| done | [fundamentals/1dof-passive-isolation.md](../fundamentals/1dof-passive-isolation.md) | 主模型、推導、第一版模擬與工程映射 |
| done | [01_1dof_passive_isolation.py](../../../../../simulations/active-vibration-isolation/01_1dof_passive_isolation.py) | damping sweep、time response、SVG / CSV 輸出 |
| done | [fundamentals/transmissibility.md](../fundamentals/transmissibility.md) | 整理 transmissibility 定義與物理意義 |
| done | [fundamentals/damping-tradeoff.md](../fundamentals/damping-tradeoff.md) | 整理 damping 的好處與代價 |
| done | [fundamentals/base-excitation-vs-direct-disturbance.md](../fundamentals/base-excitation-vs-direct-disturbance.md) | 區分地面振動與 payload 直接擾動 |
| todo | `fundamentals/passive-isolation-design-parameters.md` | 整理 `m / k / c / fn / zeta` 對設計的影響 |
| done | [01b_1dof_transmissibility_variants.py](../../../../../simulations/active-vibration-isolation/01b_1dof_transmissibility_variants.py) | 比較 `X/Y`、`(X-Y)/Y` 與 acceleration transmissibility |
| todo | `milestone-1-summary.md` | 收束 Milestone 1 的目前理解、工程判斷與待驗證問題 |

## 當前狀態

目前已完成第一版主模型與第一個可重跑模擬。
`transmissibility.md` 與 `01b` 模擬也已建立，用來區分 `X/Y`、`(X-Y)/Y` 與 `xddot/yddot`。
`damping-tradeoff.md` 已建立，用來說明 damping 壓低 resonance peak 但犧牲高頻隔震的原因。
`base-excitation-vs-direct-disturbance.md` 已建立，用來區分 floor-to-payload transmissibility 與 direct-force compliance。

已確認的 current-best 理解：

- 低頻時 `|X/Y| ~= 1`，payload 幾乎跟著 base 動。
- natural frequency 附近會出現 resonance amplification。
- damping 增加可以壓低 resonance peak。
- damping 增加會提高高頻 transmissibility，因此高頻隔震可能變差。
- 對 `X/Y` 而言，理想線性模型約在 `f > sqrt(2) * fn` 後才進入 `|X/Y| < 1` 的隔震區。

## 下一步

建議下一步先做：

1. `fundamentals/passive-isolation-design-parameters.md`
2. `milestone-1-summary.md`

原因：

- 已經完成 base excitation、transmissibility 與 damping tradeoff 的核心辨識。
- 下一步應把 `m / k / c / fn / zeta` 對設計的影響整理成參數設計頁，再收束 Milestone 1。

## 暫緩項目

以下內容不在本 milestone 深入：

- active control。
- skyhook damping。
- PID / PD controller design。
- sensor noise / filter tradeoff。
- VCM current loop。
- 3-DOF / 6-DOF 座標轉換。
- H-infinity / LMI / adaptive / switching control。

## 完成判定

本 milestone 完成時，應新增 `milestone-1-summary.md`，並在其中回答：

- 1-DOF 被動隔震的核心模型是什麼？
- transmissibility 有哪些常見定義，各自看的是什麼？
- damping tradeoff 的工程含義是什麼？
- 這些結論對後續 active control 與 VCM 實作有什麼限制？
- 哪些假設仍不能直接套用到 6-DOF 實機？
