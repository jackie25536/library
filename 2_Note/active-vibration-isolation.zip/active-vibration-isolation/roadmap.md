---
title: "主動式隔震平台研究藍圖"
type: topic
status: working
created: 2026-06-07
updated: 2026-06-08
source_count: 5
sources:
  - 2005 Model Reaching Adaptive Control for Vibration Isolation
  - 2006 Development of a Three-Axis Active Vibration Isolator Using Zero-Power Control
  - 2013 Switching Control in Vibration Isolation Systems
  - 2021 Noninteracting Control Design for 6-DoF Active Vibration Isolation Table with LMI Approach
  - 2024 A High-Precision Active Vibration Isolation Control System Experimental Study
tags:
  - active-vibration-isolation
  - vibration-control
  - VCM
  - TI-C2000
  - MIMO
  - roadmap
---

# 主動式隔震平台研究藍圖

## 定位

本主題是長期研究主題，目標不是單純讀懂幾篇 paper，而是建立能支撐 6-DoF VCM 主動隔震平台設計、模擬、調機與 TI C2000 實作的工程知識體系。

本頁是此研究主題的 current-best 入口文件。後續討論、模擬與 paper 閱讀若形成更好的理解，應回寫到本頁或拆到對應子頁。

## 目前結論

- 6-DoF 是終局目標，但不應作為第一個學習入口。
- 初期主線應先建立 1-DOF 被動隔震、1-DOF 主動控制與 VCM force actuator 的直覺。
- 多自由度問題的核心不是一開始就上 LMI / H-infinity，而是先理解剛體平台座標、致動器座標、感測器座標與解耦。
- Paper 目前作為輔助來源，用來觀察技術脈絡、常見模型與驗證方式；不直接把 paper 方法當成產品架構。
- Python 模擬應成為理解技術本質的主線工具，每個模擬都要回答一個明確問題。

## 使用者背景脈絡

使用者熟悉 TI C2000、PMSM / SPM、FOC、PI 控制、電流迴路、PWM / ISR、encoder 與實務調機。

因此本主題整理時應主動對應：

- VCM / linear actuator 的電流控制與力輸出。
- Bode plot、PID / PD、filter、feedforward 與馬達控制調機介面的相似處。
- 主動隔震外層控制與馬達速度/位置控制的差異。
- 未來在 TI C2000 上實作時的取樣率、ISR、資料記錄與 safety limit。

## 研究完成的工程目標

此研究題目完成時，應至少具備以下能力：

- 能解釋 1-DOF 被動隔震的 transmissibility、resonance 與 damping tradeoff。
- 能建立 1-DOF 主動隔震模型，並模擬 PID / PD、skyhook、filter、noise tradeoff。
- 能說明 VCM 作為 force actuator 時，內層電流迴路與外層隔震控制的分工。
- 能從 1-DOF 擴展到 3-DOF / 6-DOF 剛體平台座標轉換。
- 能理解 actuator allocation、sensor reconstruction、modal decomposition 與 axis decoupling。
- 能對應商用隔震控制介面中的 Bode plot、feedforward、PID、filter 與 coupling adjustment。
- 能規劃 TI C2000 prototype 的控制架構與驗證流程。

## Companion Notes

- [主動式隔震平台關鍵字地圖](keyword-map.md)
- [主動式隔震平台模擬路線](simulation-roadmap.md)
- [主動式隔震平台 C2000 韌體實作分支藍圖](c2000-implementation-branch.md)

## 主線技術文件

- [1-DOF 被動隔震模型](fundamentals/1dof-passive-isolation.md)
- [Transmissibility 定義與物理意義](fundamentals/transmissibility.md)
- [Damping Tradeoff：阻尼壓共振但犧牲高頻隔震](fundamentals/damping-tradeoff.md)
- [Base Excitation vs Direct Disturbance](fundamentals/base-excitation-vs-direct-disturbance.md)

## Milestone 追蹤

- [Milestone 1：1-DOF 被動隔震模型](milestones/milestone-1-1dof-passive-isolation.md)

## 研究主線

建議主線：

1. 1-DOF 被動隔震。
2. 1-DOF 主動控制。
3. VCM force actuator 與 current loop。
4. 3-DOF / 6-DOF 剛體座標轉換。
5. MIMO decoupling 與調機流程。
6. C2000 prototype 架構。
7. 回收進階 paper 方法。

## Milestone 0：研究藍圖與術語整理

目標：建立全局地圖，避免被單篇 paper 或進階控制方法牽著走。

產出：

- 本 roadmap。
- [關鍵字地圖](keyword-map.md)。
- 候選 paper 清單。
- 待驗證問題清單。
- 隔震與馬達控制對照表。

Gate：

- 能說明主動隔震要解決的是 transmissibility、direct disturbance、platform vibration、axis interaction，而不只是位置控制。

## Milestone 1：1-DOF 被動隔震模型

目標：建立最小物理模型。

進度追蹤：

- [Milestone 1：1-DOF 被動隔震模型](milestones/milestone-1-1dof-passive-isolation.md)

必學：

- mass-spring-damper。
- base excitation。
- transmissibility。
- resonance frequency。
- damping ratio。
- payload response。

產出：

- [1-DOF 被動隔震模型](fundamentals/1dof-passive-isolation.md)。
- Bode plot 模擬。
- time response 模擬。
- damping tradeoff 說明。

Gate：

- 能說明為什麼低頻隔震困難。
- 能說明 damping 增加後，resonance 下降但高頻隔震可能變差。

## Milestone 2：1-DOF 主動隔震控制

目標：建立可調機的最小主動控制模型。

必學：

- feedback control。
- skyhook damping。
- PID / PD / lead-lag。
- notch / low-pass filter。
- sensor noise amplification。
- actuator force limit。

產出：

- 1-DOF active control block diagram。
- PID / PD 模擬。
- skyhook 模擬。
- filter 對 Bode 與 noise 的影響。
- 控制力飽和與 safety limit 初步規則。

Gate：

- 能說明為什麼 active control 不能無限制提高 gain。
- 能說明 feedback isolation performance 與 sensor noise 的 tradeoff。

## Milestone 3：VCM 與馬達控制映射

目標：把隔震致動器接回使用者熟悉的馬達控制語言。

必學：

- VCM force constant。
- current loop。
- force command to current command。
- current sensing。
- voltage / current / thermal limit。
- actuator bandwidth。

產出：

- VCM 控制方塊圖。
- PMSM / VCM / linear motor 對照。
- 內層電流迴路與外層隔震控制分工。
- TI C2000 可行架構初稿。

Gate：

- 能明確區分「電流控制像馬達控制」與「隔震外層目標不同」。

## Milestone 4：3-DOF / 6-DOF 剛體平台

目標：從單軸模型進入多自由度平台，但先理解座標，不急著進入 LMI / H-infinity。

必學：

- rigid body DOF。
- platform coordinate。
- actuator coordinate。
- sensor coordinate。
- transformation matrix。
- actuator allocation。
- sensor reconstruction。
- modal decomposition。

產出：

- 3-DOF 平台模型。
- 6-DOF 座標定義。
- actuator / sensor matrix 筆記。
- local control vs mode control 對照。

Gate：

- 能說明為什麼多個 actuator 不等於多個獨立 SISO axis。
- 能說明如何從 actuator force 轉成 platform force/torque。

## Milestone 5：6-DOF 解耦與調機流程

目標：建立接近商用 IDE 的工程調機框架。

必學：

- MIMO frequency response。
- diagonal / off-diagonal Bode matrix。
- axis interaction。
- feedforward compensation。
- decoupling matrix。
- SISO loop shaping after decoupling。

產出：

- Bode plot 觀察清單。
- axis coupling 診斷流程。
- PID / filter / feedforward 調整流程。
- 商用 IDE 功能對應表。

Gate：

- 能看懂單軸 Bode 與 MIMO Bode matrix 的差異。
- 能說明某軸控制為什麼會激發另一軸振動。

## Milestone 6：進階 paper 方法回收

目標：在基礎模型建立後，再整理進階方法的位置。

候選方法：

- model-reaching adaptive control。
- zero-power control。
- switching control。
- noninteracting control with LMI。
- robust decoupling control。
- mixed-sensitivity H-infinity。

產出：

- 每種方法的問題定位。
- 所需前置知識。
- 可否工程實作的評估。
- 是否適合 TI C2000 prototype。

Gate：

- 不把 paper 方法直接當產品架構。
- 能指出該方法解決的是哪個具體問題。

## Milestone 7：TI C2000 Prototype 規劃

目標：把控制理論收斂到可實作架構。

必學：

- sampling rate。
- ISR partition。
- current loop。
- outer vibration loop。
- sensor acquisition。
- data logging。
- online frequency response measurement。
- safety limit。
- fault handling。

產出：

- C2000 control architecture。
- task timing。
- data path。
- tuning parameters。
- test plan。

Gate：

- 能定義最小可跑 prototype，而不是一次做完整產品。

## 一年期節奏

Q1：基礎與 1-DOF。

- 完成 roadmap、關鍵字地圖、1-DOF 被動/主動模型、Bode 與 time response 模擬。

Q2：VCM 與可實作控制。

- 完成 VCM force actuator 映射、current loop / outer loop 分工、sensor noise / filter tradeoff、初版 C2000 實作藍圖。

Q3：多自由度與解耦。

- 完成 3-DOF 到 6-DOF 座標、actuator/sensor matrix、modal decomposition、MIMO Bode matrix、axis coupling 診斷。

Q4：prototype 定義與 paper 回收。

- 完成最小可跑 prototype 規格、調機流程、Bode injection / logging 規劃，並回頭整理 paper 中真正有用的方法。

一年後的合理初步版本不是完整產品，而是能用模擬與筆記說清楚 6-DoF VCM 主動隔震平台的控制架構，知道怎麼量測、怎麼調、怎麼落到 C2000 prototype。

## 研究節奏

- 平日：閱讀目前整理好的主線文件，直接提出不懂或卡住的問題。
- 週末：挑 1 到 3 個問題深入討論，必要時用 Python 建最小模擬輔助理解。
- 討論後：先形成 note 草稿或修正方向，再回寫到對應 wiki 文件。
- 每季：檢查 milestone gate，調整下一季優先順序。

## 暫緩項目

以下項目暫緩，不作為第一階段主線：

- 完整 6-DOF 高精度建模。
- H-infinity / LMI / adaptive / switching control 深入推導。
- 論文級最佳化控制設計。
- 最終產品韌體架構。
- 未確認硬體規格下的細節參數設計。

## 候選 paper 來源

目前候選來源包含：

- 2005 Model Reaching Adaptive Control for Vibration Isolation。
- 2006 Development of a Three-Axis Active Vibration Isolator Using Zero-Power Control。
- 2013 Switching Control in Vibration Isolation Systems。
- 2021 Noninteracting Control Design for 6-DoF Active Vibration Isolation Table with LMI Approach。
- 2024 A High-Precision Active Vibration Isolation Control System Experimental Study。

這些 paper 暫時作為輔助來源，不立即逐篇正式 ingest。後續依研究里程碑需要，再建立 raw bundle 與 discussion notes。

## 待驗證問題

- 目標平台的有效 payload mass、尺寸、重心變化範圍為何？
- VCM 數量、配置、force constant、stroke、電流限制與頻寬為何？
- 感測器使用 geophone、accelerometer、position sensor，或混合感測？
- 控制目標偏向 floor vibration isolation、direct disturbance rejection，或 platform stabilization？
- 目標頻帶為何？
- C2000 是否只負責控制，還是也要負責 Bode injection / data logging？
