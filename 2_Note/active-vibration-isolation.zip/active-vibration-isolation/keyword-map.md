---
title: "主動式隔震平台關鍵字地圖"
type: topic
status: working
created: 2026-06-07
updated: 2026-06-07
tags:
  - active-vibration-isolation
  - keyword-map
  - learning-roadmap
---

# 主動式隔震平台關鍵字地圖

## 目的

本頁用來把主動式隔震平台研究拆成可學習、可討論、可回查的關鍵字群。

關鍵字不是背誦清單，而是用來判斷：

- 這個概念屬於物理、控制、感測、致動、調機、韌體或進階 paper 方法。
- 它應該在哪個 milestone 學。
- 它是否能對應到使用者既有的馬達控制經驗。
- 它目前是主線、輔助，還是暫緩。

## 優先順序

第一優先：

- 1-DOF 被動隔震。
- transmissibility。
- Bode plot。
- PID / PD / filter。
- VCM current-to-force mapping。

第二優先：

- 3-DOF / 6-DOF 座標轉換。
- actuator allocation。
- sensor reconstruction。
- MIMO Bode matrix。
- decoupling matrix。

第三優先：

- H-infinity。
- LMI。
- adaptive control。
- switching control。
- zero-power control。

## 1. 物理與機械本質

關鍵字：

- mass-spring-damper
- base excitation
- transmissibility
- resonance
- natural frequency
- damping ratio
- payload
- center of mass
- rigid body
- compliance
- stiffness
- floor vibration
- direct disturbance
- platform vibration
- isolation bandwidth

學習目的：

- 理解隔震不是單純位置控制。
- 理解低頻、共振、高頻隔震之間的 tradeoff。
- 建立 1-DOF 被動隔震模型。

工程映射：

- 對應馬達控制中的 load resonance、mechanical compliance 與 speed/position loop bandwidth 限制。
- 但隔震的目標通常是降低外部振動傳遞與平台振動，而不是追蹤命令軌跡。

## 2. 1-DOF 主動控制

關鍵字：

- feedback control
- feedforward control
- PID
- PD
- lead-lag
- skyhook damping
- notch filter
- low-pass filter
- high-pass filter
- loop shaping
- disturbance rejection
- sensor noise amplification
- actuator saturation
- force limit
- stability margin

學習目的：

- 建立最小主動隔震控制模型。
- 連結 Bode plot、PID、filter 與實務調機。
- 理解 active control 為什麼不能只提高 gain。

工程映射：

- 類似 servo loop tuning 中的 bandwidth / phase margin / noise tradeoff。
- 差異是主動隔震特別重視 floor vibration transmissibility 與 direct disturbance rejection。

## 3. VCM 與致動器

關鍵字：

- VCM
- voice coil motor
- force constant
- current loop
- force command
- current command
- stroke
- back EMF
- actuator bandwidth
- voltage limit
- current limit
- thermal limit
- linear actuator
- force actuator
- Lorentz force

學習目的：

- 把 VCM 視為受電流控制的力源。
- 區分內層電流控制與外層隔震控制。
- 對應使用者既有 PMSM / current loop 經驗。

工程映射：

- VCM current loop 可類比 PMSM 的 q-axis current loop。
- VCM 通常不需要 Park / Clarke / rotor angle，但會受到 stroke、coil thermal、back EMF、功放頻寬與力常數限制。

## 4. 感測與訊號

關鍵字：

- accelerometer
- geophone
- velocity sensor
- position sensor
- sensor fusion
- noise floor
- bias
- drift
- phase delay
- anti-aliasing filter
- sampling rate
- resolution
- quantization noise
- signal conditioning
- sensor placement

學習目的：

- 理解隔震控制高度受感測器 noise / delay 限制。
- 判斷不同感測器適合量測 displacement、velocity 或 acceleration。
- 對應未來 C2000 資料鏈與濾波設計。

工程映射：

- 感測器 noise / delay 會直接限制可用控制頻寬，類似 encoder noise 對速度估測與速度迴路的限制。
- 隔震平台可能同時需要絕對運動與相對位移資訊，感測鏈比一般 motor drive 更像 motion metrology 問題。

## 5. 多自由度與座標轉換

關鍵字：

- 3-DoF
- 6-DoF
- translation
- rotation
- roll
- pitch
- yaw
- platform coordinate
- actuator coordinate
- sensor coordinate
- transformation matrix
- actuator allocation
- sensor reconstruction
- modal decomposition
- mode control
- local control
- rigid-body mode

學習目的：

- 理解多個 actuator 不等於多個獨立 SISO axis。
- 建立 actuator force 到 platform force/torque 的映射。
- 從 1-DOF 逐步走向 6-DOF。

工程映射：

- 類似多馬達平台或 gantry 的座標轉換與力矩分配，但隔震平台更重視剛體模態、耦合與頻域響應。

## 6. MIMO 解耦與調機

關鍵字：

- MIMO plant
- SISO loop
- decoupling matrix
- cross coupling
- axis interaction
- diagonal response
- off-diagonal response
- Bode matrix
- FRF
- transmissibility curve
- compliance curve
- gain margin
- phase margin
- coherence
- sine sweep
- frequency response measurement

學習目的：

- 看懂商用 IDE 中的 Bode / coupling / filter 調機語言。
- 判斷某一軸控制為什麼會激發另一軸。
- 建立 6-DOF 調機流程。

工程映射：

- 單軸 Bode 只看一條輸入輸出路徑；MIMO Bode matrix 需要同時看 diagonal 與 off-diagonal response。
- decoupling 後仍可能有 residual coupling，不能假設每軸完全獨立。

## 7. 模擬與識別

關鍵字：

- transfer function
- state-space
- time response
- frequency response
- parameter identification
- model validation
- linear model
- nonlinear effect
- simulation-in-loop
- log replay
- plant model
- base input model
- disturbance model

學習目的：

- 建立從模型到實驗資料的閉環。
- 不追求一開始就精準，而是建立可驗證、可修正的模型。
- 區分理論模型、候選模型與實機識別模型。

工程映射：

- 模擬應服務工程問題，例如「某個 filter 是否改善 transmissibility」或「current loop bandwidth 是否限制外層控制」。
- 不做沒有驗證目標的複雜模型。

## 8. TI C2000 韌體實作

關鍵字：

- ISR
- PWM
- ADC
- CLA
- SDFM
- data logging
- online injection
- parameter update
- saturation
- anti-windup
- fault handling
- watchdog
- real-time task
- matrix computation
- floating point
- fixed point
- current sensing
- safety limit

學習目的：

- 確保控制方法最後能落到 MCU。
- 評估取樣率、運算量、資料記錄與保護機制。
- 連結使用者既有 C2000 實務經驗。

工程映射：

- C2000 適合 deterministic real-time control。
- 大量資料分析與圖形化 Bode 顯示可先交給 PC tool，MCU 先負責 injection、logging 與即時控制。

## 9. 進階 paper 方法

關鍵字：

- adaptive control
- model-reaching control
- skyhook target
- zero-power control
- switching control
- noninteracting control
- LMI
- H-infinity control
- mixed-sensitivity
- robust control
- sliding mode control
- modal decoupling

學習目的：

- 後期回收 paper 的新方法與觀點。
- 判斷每種方法解決的具體問題。
- 不在基礎未建立前深陷進階數學。

工程映射：

- 這些方法應先定位為候選方案或分析工具。
- 是否適合 C2000 prototype，需要等模型、感測鏈、運算量與調機流程清楚後再判斷。

## 待補

- 每個關鍵字補上簡短定義。
- 每個關鍵字連到對應 wiki note。
- 標記每個關鍵字屬於哪個 milestone。
- 補上和馬達控制語言的對照表。

