---
title: "主動式隔震平台 C2000 韌體實作分支藍圖"
type: topic
status: working
created: 2026-06-07
updated: 2026-06-07
tags:
  - active-vibration-isolation
  - TI-C2000
  - firmware
  - VCM
  - implementation
---

# 主動式隔震平台 C2000 韌體實作分支藍圖

## 定位

本頁不是立即開始寫韌體，而是作為長期研究中的實作可行性檢查線。

主研究線處理：

```text
1-DOF model -> active control -> 6-DOF decoupling -> tuning
```

本分支處理：

```text
loop timing -> current loop -> sensor acquisition -> data logging -> safety -> tuning interface
```

目的：避免控制理論學到後期才發現不適合 C2000、VCM、感測器或實機調機流程。

## 目前結論

- C2000 適合 deterministic real-time control。
- 第一版 prototype 不應要求 MCU 直接畫 Bode plot；MCU 先負責 injection、logging 與即時控制，PC tool 負責 FRF / Bode / coherence 分析。
- VCM 底層需要 current loop，外層隔震控制輸出 force command，再轉成 current command。
- 外層控制目標不是追位置軌跡，而是降低 vibration response、transmissibility 或 direct disturbance response。

## 系統邊界

待定問題：

- C2000 是否負責 VCM 電流迴路？
- C2000 是否同時負責外層隔震控制？
- Bode injection / frequency response estimation 是否在 MCU 內完成？
- data logging 是 MCU 內建、外接 recorder，還是上位機完成？
- 參數調整是否需要即時更新？
- 是否需要多 MCU 或 FPGA / DAQ 輔助？

初步假設：

- VCM 底層需要 current loop。
- 外層隔震控制輸出 force command，再轉成 current command。
- C2000 適合做 deterministic real-time control。
- 大量資料分析與圖形化 Bode 顯示可先交給 PC tool。

## 控制迴路分層

### Inner loop：VCM current loop

功能：

- 控制 coil current。
- 將 current command 轉成實際 force。
- 處理 current sensing、PWM、voltage / current limit。

與使用者既有經驗的對應：

- 類似馬達控制中的 q-axis current loop。
- 差異是 VCM 通常不需要 Park / Clarke / rotor angle。
- force command 與 current command 關係較直接，但仍受 stroke、thermal、back EMF 與 amplifier 限制。

### Outer loop：vibration control loop

功能：

- 根據 platform motion sensor 產生 force command。
- 實作 PID / PD / skyhook / filter / decoupling。
- 處理 sensor noise、phase delay、axis coupling。

注意：

- 外層控制目標不是追位置軌跡，而是降低 vibration response。
- gain 太高可能放大 sensor noise 或激發未建模模態。

### Supervisory loop

功能：

- parameter management。
- limit monitoring。
- fault handling。
- mode switching。
- logging control。
- safe disable / rollback。

## 取樣率與任務規劃

待驗證：

- current loop bandwidth。
- vibration control bandwidth。
- sensor sampling rate。
- Bode injection 頻帶。
- 6-DOF matrix computation cost。

初步原則：

- current loop 頻率應高於 outer vibration loop。
- outer loop 頻率需覆蓋目標隔震頻帶並保留相位裕度。
- logging 不應破壞 deterministic ISR timing。
- 6-DOF matrix 運算需先估算 CLA / CPU 負載。

## 感測鏈

候選感測器：

- accelerometer。
- geophone。
- velocity sensor。
- position sensor。
- 混合感測。

需研究問題：

- 量測目標是 displacement、velocity 還是 acceleration？
- 感測器 noise floor 是否限制低頻控制？
- phase delay 對 stability margin 的影響？
- 是否需要 sensor fusion？
- sensor coordinate 如何轉成 platform DOF？

## 調機與識別功能

最低需求：

- sine injection。
- frequency response measurement。
- Bode plot offline reconstruction。
- parameter save / load。
- filter enable / disable。
- controller gain update。
- log export。

進階需求：

- online FRF estimation。
- coherence calculation。
- MIMO Bode matrix。
- axis coupling diagnosis。
- automatic sweep safety check。

初步策略：

- 第一版 prototype 不要求 MCU 直接畫 Bode。
- MCU 負責 injection 與 logging。
- PC tool 負責 Bode / FRF / coherence 分析。

## 保護機制

必要保護：

- current limit。
- voltage limit。
- stroke limit。
- thermal limit。
- sensor fault。
- actuator fault。
- unstable response detection。
- emergency stop。
- controller parameter rollback。

控制相關保護：

- force command saturation。
- current command saturation。
- anti-windup。
- filter coefficient validation。
- mode transition ramp。
- integrator reset rule。

## 一年期實作分支里程碑

### Q1：模型可實作性檢查

產出：

- 1-DOF active control block diagram。
- force command to current command 初步定義。
- logging signal list。
- C2000 可能任務分層草圖。

Gate：

- 能說明模型中的 force actuator 如何對應到 VCM current loop。

### Q2：VCM 與感測鏈分工

產出：

- VCM current loop 架構。
- sensor acquisition pipeline。
- filter / delay / noise 初步分析。
- outer loop sampling rate 初步假設。

Gate：

- 能區分 current loop 問題與 vibration loop 問題。

### Q3：6-DOF 運算與調機資料路徑

產出：

- actuator / sensor matrix 運算流程。
- 6-DOF force command data path。
- MIMO Bode logging 規劃。
- CPU / CLA 運算量初估。

Gate：

- 能判斷 6-DOF decoupling 是否適合放在 C2000 即時迴路。

### Q4：最小 prototype 定義

產出：

- 最小可跑控制架構。
- required signals。
- tuning parameters。
- safety parameters。
- test plan。
- offline analysis flow。

Gate：

- 能定義一個不完整但可驗證的 prototype，而不是一次做產品級系統。

## 暫緩項目

- 完整商用調機軟體。
- 自動調參。
- 完整 H-infinity / LMI 韌體化。
- 多 MCU 同步架構。
- 未確認硬體規格下的最終取樣率。

